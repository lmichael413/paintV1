package com.company;

import javafx.scene.canvas.Canvas;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class UseZoomTest {

    private Canvas paintTest;
    private static double canvasScale = 1;

    @Before
    public void setUp() throws Exception {
        paintTest = new Canvas(600,600);

    }

    @Test
    public void zoomInTest() {
        Canvas zoomTest = new Canvas(600,600);
        paintTest.setScaleX(1);
        paintTest.setScaleY(1);
        zoomTest.setScaleX(1.2);
        zoomTest.setScaleY(1.2);
        UseZoom.zoomIn(paintTest);
        assertEquals(zoomTest.getScaleX(),paintTest.getScaleX(),0.005);
        assertEquals(zoomTest.getScaleY(),paintTest.getScaleY(),0.005);
    }

    @Test
    public void zoomOutTest() {
        Canvas zoomTest = new Canvas(600,600);
        paintTest.setScaleX(1);
        paintTest.setScaleY(1);
        zoomTest.setScaleX(0.8);
        zoomTest.setScaleY(0.8);
        UseZoom.zoomOut(paintTest);
        assertEquals(zoomTest.getScaleX(),paintTest.getScaleX(),0.005);
        assertEquals(zoomTest.getScaleY(),paintTest.getScaleY(),0.005);
    }
}