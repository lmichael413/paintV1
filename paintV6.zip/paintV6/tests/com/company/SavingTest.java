package com.company;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class SavingTest {

    private static int saveCount;

    private static boolean changeCheck;

    @Before
    public void setUp() throws Exception {

    }

    @Test
    public void setChangeCheck() {
        try{
            Saving.setChangeCheck(false);
            Saving.setChangeCheck(true);
        }
        catch(IllegalArgumentException e){
            System.out.println("caught incorrect change to setChangeCheck");
        }
        catch(Exception ex){
            System.out.println("caught an exception with setChangeCheck");
        }

    }

    @Test
    public void testChangeCheckTrue() {
        Saving.setChangeCheck(true);
        Boolean yay = true;
        assertEquals(yay,Saving.getChangeCheck());


    }

    @Test
    public void testChangeCheckFalse() {
        Saving.setChangeCheck(true);
        Boolean nay = false;
        assertEquals(nay,Saving.getChangeCheck());


    }

    @Test
    public void testGetChangeCheck() {
        Saving.setChangeCheck(false);
        Boolean tGCC = Saving.getChangeCheck();
        Boolean nay = false;
        assertEquals(nay,tGCC);

    }


}