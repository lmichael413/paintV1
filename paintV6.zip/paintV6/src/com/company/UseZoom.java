package com.company;


import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.ScrollPane;



public class UseZoom {

    //the scale that the canvas uses, set to the default of 1
    private static double canvasScale = 1;


    /**
     *Method in charge of zooming in of the canvas
     *
     * @param paintGround the canvas that is going to be zoomed in on
     */
    public static void zoomIn(Canvas paintGround){
        paintGround.setScaleX(canvasScale + 0.2);
        paintGround.setScaleY(canvasScale + 0.2);
        canvasScale = canvasScale + 0.2;

    }

    /**
     *Method in charge of zooming out of the canvas
     *
     * @param paintGround the canvas that is going to be zoomed in on
     */
    public static void zoomOut(Canvas paintGround){
        paintGround.setScaleX(canvasScale - 0.2);
        paintGround.setScaleY(canvasScale - 0.2);
        canvasScale = canvasScale - 0.2;

    }
}
