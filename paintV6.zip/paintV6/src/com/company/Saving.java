package com.company;


import java.awt.image.BufferedImage;
import java.awt.image.RenderedImage;
import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;

import javafx.embed.swing.SwingFXUtils;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.WritableImage;
import javafx.scene.layout.GridPane;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javax.imageio.ImageIO;

/**
 * In charge of saving the canvas to a file
 */
public class Saving {

    /**
     *The core variables that are shared throughout the program
     *
     *saveCount     an integer that increases as the SaveCanvas is ran.
     *                      It's goal is to catch if a user hasn't saved once if they close.
     *
     *changeCheck   a boolean that tells the program if a change has occured to the
     *                      canvas. Is made true whenever a change occurs. If true when the
     *                      program is closed will ask the user to save.
     */
    private static int saveCount = 0;

    private static boolean changeCheck = false;


    /**
     * Saves a Canvas to a location specified by the user. The user can choose from three
     * file types
     *
     * @param paintGround       Canvas that is going to be saved to the output location.
     *
     * @param s                 Stage that is used to get the output location.
     */
    public static void saveCanvas(Canvas paintGround, Stage s) {
        FileChooser fileChooser = new FileChooser();

        //Set extension filter to png
        FileChooser.ExtensionFilter jpgFilter = new FileChooser.ExtensionFilter("jpg", "*.jpg");
        FileChooser.ExtensionFilter pngFilter = new FileChooser.ExtensionFilter("png", "*.png");
        FileChooser.ExtensionFilter jpegFilter = new FileChooser.ExtensionFilter("jpeg", "*.jpeg");


        fileChooser.getExtensionFilters().add(jpgFilter);
        fileChooser.getExtensionFilters().add(pngFilter);
        fileChooser.getExtensionFilters().add(jpegFilter);

        //The output space
        File filespace = fileChooser.showSaveDialog(s);

        //writing the file
        if (filespace != null) {
            try {
                if (saveCount == 0) {
                    saveCount = 1;
                }
                WritableImage writableImage = new WritableImage((int) paintGround.getWidth(), (int) paintGround.getHeight());
                paintGround.snapshot(null, writableImage);
                RenderedImage renderedImage = SwingFXUtils.fromFXImage(writableImage, null);
                ImageIO.write(renderedImage, "png", filespace);
                setChangeCheck(false);

            } catch (IOException ex) {
                System.out.println("error in saving file");
            }
        }
    }

    /*public static void autoSave(Canvas paintGround, GraphicsContext graphCon)  {

        WritableImage writableImage = new WritableImage((int)paintGround.getWidth(),
                (int)paintGround.getHeight());
        Image autoImage = paintGround.snapshot(null,writableImage);




    }*/


    /**
     * Draws the autoSaved image on the chosen Canvas
     *
     * @param paintGround       the chosen Canvas that will have the autosave drawn on
     *
     * @param graphCon          the GraphicContext that is used to draw on the Canvas
     *
     * @param autoImage         the autosaved Image.
     */
    public static void drawAutoSave(Canvas paintGround, GraphicsContext graphCon, Image autoImage){

        paintGround.setWidth(autoImage.getWidth());
        paintGround.setHeight(autoImage.getHeight());
        graphCon.drawImage(autoImage,0,0);
    }

    public static void setChangeCheck(Boolean tfInput){

        changeCheck = tfInput;

    }

    /**
     * Creates a new window where the user can change the time it takes to autosave. The change
     * takes places as soon as the Change Auto Time button is clicked.
     *
     * @param autoTime      the current time that it takes to autosave.
     *
     */

    public static void changeAutoTime(int autoTime){

        TextField autoTimeField = new TextField(String.valueOf(autoTime));

        Button timeConfirm = new Button("Change Auto Time");

        GridPane root = new GridPane();
        root.setAlignment(Pos.CENTER);

        root.add(timeConfirm, 0, 0);
        root.add(autoTimeField, 1, 0);

        autoTimeField.setPrefWidth(70);
        timeConfirm.setPrefWidth(70);

        timeConfirm.setOnAction(e -> paintV6.autoTime = Integer.parseInt(autoTimeField.getText()));
        Scene scene = new Scene(root, 200, 200);

        Stage releaseWindow = new Stage();
        releaseWindow.setTitle("Autosave Timer");
        releaseWindow.setScene(scene);

        releaseWindow.setX(200);
        releaseWindow.setY(100);


        releaseWindow.show();

    }

    public static Boolean getChangeCheck(){
        return changeCheck;
    }

    public static void setSaveCount(int newCount){
        saveCount = newCount;
    }

    public static Integer getSaveCount(){
        return saveCount;
    }



}