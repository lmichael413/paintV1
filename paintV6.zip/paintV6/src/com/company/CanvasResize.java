package com.company;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.WritableImage;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;


public class CanvasResize {

    public static TextField canvasWidth;
    public static TextField canvasHeight;
    public static Button updateSize;



    /**
     * The method in charge of resizing the canvas to new dimensions chosen by the user
     *      This is done by having a new window popup and get the resized dimensions
     *
     * @param paintGround the canvas that is going to be resized
     *
     * @param graphCon the graphic context used
     */
    public static void resizeCanvas(Canvas paintGround, GraphicsContext graphCon){
        canvasWidth = new TextField(String.valueOf(paintGround.getWidth()));
        canvasHeight = new TextField(String.valueOf(paintGround.getHeight()));
        updateSize = new Button("Update Size");

        GridPane root = new GridPane();
        root.setAlignment(Pos.CENTER);

        root.add(updateSize, 0, 0);
        root.add(canvasWidth, 0, 2);
        root.add(canvasHeight, 1, 2);

        canvasWidth.setPrefWidth(70);
        canvasHeight.setPrefWidth(70);
        updateSize.setPrefWidth(70);

        updateSize.setOnAction(e -> rescalePaint(paintGround, graphCon));
        Scene scene = new Scene(root, 200, 200);

        Stage releaseWindow = new Stage();
        releaseWindow.setTitle("Canvas Resize");
        releaseWindow.setScene(scene);

        releaseWindow.setX(200);
        releaseWindow.setY(100);

        //showing
        releaseWindow.show();
        Saving.setChangeCheck(true);

    }


    /**
     *Method called by the resize window rescaling what is painted to the new canvas size
     *
     * @param paintGround the canvas that is going to be resized
     *
     * @param graphCon the graphic context used
     */
    public static void rescalePaint(Canvas paintGround, GraphicsContext graphCon) {
        double newWidth = Double.parseDouble(canvasWidth.getText());
        double newHeight = Double.parseDouble(canvasHeight.getText());


        //RenderedImage safeImage = SwingFXUtils.fromFXImage(writableImage, null);


        WritableImage writableImage = new WritableImage((int)paintGround.getWidth(), (int)paintGround.getHeight());

        double scaleWidth = newWidth/paintGround.getWidth();
        double scaleHeight = newHeight/paintGround.getHeight();
        double reverseWidth = paintGround.getWidth()/newWidth;
        double reverseHeight = paintGround.getHeight()/newHeight;

        graphCon.scale(scaleWidth,scaleHeight);

        if(newWidth>=paintGround.getWidth()&&newHeight>=paintGround.getHeight()) {
            paintGround.setWidth(newWidth);
            paintGround.setHeight(newHeight);

            graphCon.drawImage(paintGround.snapshot(null, writableImage), 0, 0);
            graphCon.scale(reverseWidth, reverseHeight);

        }
        else{
            graphCon.drawImage(paintGround.snapshot(null, writableImage), 0, 0);
            paintGround.setWidth(newWidth);
            paintGround.setHeight(newHeight);

            graphCon.scale(reverseWidth, reverseHeight);
        }




    }

}
