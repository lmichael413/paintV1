package com.company;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.canvas.Canvas;
import javafx.scene.image.Image;
import javafx.scene.image.WritableImage;

import java.util.Stack;


/**
 *The Class in charge of the undo function
 */
public class UndoEdit {


    /**
     *The method in charge of undoing the previous action on the  canvas
     *
     * @param pastCanvas a stack that contains images of all previous changes
     *
     * @param futureCanvas a stack that contains images of the canvases undone
     *
     * @param paintGround the canvas to be painted on
     *
     * @param graphCon the graphic context used to draw
     */
    public static void undo(Stack<Image> pastCanvas, Stack<Image> futureCanvas, Canvas paintGround, GraphicsContext graphCon){

        WritableImage writableImage = new WritableImage((int)paintGround.getWidth(),
                (int)paintGround.getHeight());


        //putting the old canvas in the redo stack
        futureCanvas.push(paintGround.snapshot(null,writableImage));
        Image test = pastCanvas.pop();
        //futureCanvas.push(test);

        //drawing the undo
        paintGround.setWidth(test.getWidth());
        paintGround.setHeight(test.getHeight());
        graphCon.drawImage(test,0,0);

        //if undo stack is empty, put a blank canvas in the redo
        if(pastCanvas.isEmpty()){
            WritableImage defaultImage = new WritableImage((int)paintGround.getWidth(),
                    (int)paintGround.getHeight());
            pastCanvas.push(paintGround.snapshot(null,defaultImage));
        }

    }

    /**
     *A method to redo what was previously undone
     *
     * @param pastCanvas a stack that contains images of all previous changes
     *
     * @param futureCanvas a stack that contains images of the canvases undone
     *
     * @param paintGround the canvas to be painted on
     *
     * @param graphCon the graphic context used to draw
     */
    public static void redo(Stack<Image> pastCanvas, Stack<Image> futureCanvas, Canvas paintGround, GraphicsContext graphCon){


        pastCanvas.push(futureCanvas.peek());

        //put previous canvas in the undo stack
        Image test = futureCanvas.pop();


        //draw redo canvas
        paintGround.setWidth(test.getWidth());
        paintGround.setHeight(test.getHeight());
        graphCon.drawImage(test,0,0);

        if(pastCanvas.isEmpty()){
            WritableImage writableImage = new WritableImage((int)paintGround.getWidth(),
                    (int)paintGround.getHeight());
            pastCanvas.push(paintGround.snapshot(null,writableImage));
        }

    }

    /**
     *A method that puts the current canvas into the undo stack
     *
     * @param pastCanvas a stack that contains images of all previous changes
     *
     * @param paintGround the canvas to be painted on
     */
    public static void addUndoStack(Stack<Image> pastCanvas,Canvas paintGround){

        //a function that puts the canvas into the undostack
        WritableImage writableImage = new WritableImage((int)paintGround.getWidth(),
                (int)paintGround.getHeight());
        pastCanvas.push(paintGround.snapshot(null,writableImage));

    }
}
