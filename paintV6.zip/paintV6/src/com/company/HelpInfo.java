package com.company;

import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

/**
 *The class in charge of the Help function
 */
public class HelpInfo {

    /**
     *The method in charge of creating the Help screen
     *      by creating a new window with the text information
     */
    public static void getHelpInfo() {

        //setting up the text for help notes
        Label secondLabel = new Label("Help Info" +
                "\nButtons are used for direct involvement with the canvas" +
                "\n"+"\nFile allows you to open an image and save" +
                "\n\n Edit allows you to interact with the canvas itself" +
                "\n\n Help allows you to see release notes and get here" +
                "\n\n Shift S is quick save      Shift U is undo");

        //making it show
        StackPane secondaryLayout = new StackPane();
        secondaryLayout.getChildren().add(secondLabel);

        Scene secondScene = new Scene(secondaryLayout, 500, 150);

        Stage releaseWindow = new Stage();
        releaseWindow.setTitle("Second Stage");
        releaseWindow.setScene(secondScene);

        releaseWindow.setX(200);
        releaseWindow.setY(100);

        //showing
        releaseWindow.show();
    }
}