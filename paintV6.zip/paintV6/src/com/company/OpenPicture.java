package com.company;


import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.stage.FileChooser;
import java.util.Stack;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;



public class OpenPicture {

    /**
     * Method in charge of opening a picture. It does this by prompting the user to choose a filepath
     *      then converting the image from the filepath into a image
     *
     * @param pastCanvas a stack of all the past canvases worked on. Adds the canvas before the image is
     *        opened
     *
     * @param paintGround the canvas that the image will be opened on
     *
     * @param graphCon the graphic context that will draw the image
     */

    public static void openPicture(Stack<Image> pastCanvas, Canvas paintGround, GraphicsContext graphCon){
        //picking the file
        UndoEdit.addUndoStack(pastCanvas,paintGround);
        FileChooser fileChooser = new FileChooser();
        FileChooser.ExtensionFilter extFilterJPG = new FileChooser.ExtensionFilter("Image Files", "*.jpg", "*.png","*.jpeg");
        fileChooser.getExtensionFilters().addAll(extFilterJPG);

        File chosenFile = fileChooser.showOpenDialog(null);
        //making sure you picked an image
        try {
            Image chosenImage = new Image(new FileInputStream(chosenFile));
            if(chosenImage.getHeight()>paintGround.getHeight()){
                paintGround.setHeight(chosenImage.getHeight());
            }
            if(chosenImage.getWidth()>paintGround.getWidth()){
                paintGround.setWidth(chosenImage.getWidth());

            }
            graphCon.drawImage(chosenImage, 0, 0);
            Saving.setChangeCheck(true);

        } catch (IOException ex) {

        }

    }
}
