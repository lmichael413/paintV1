package com.company;

import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import static com.company.paintV6.currentX;
import static com.company.paintV6.currentY;



public class ToolBarFun {

    /**
     *Everything in charge of setting up the Toolbars, all of them have effectively the same parameters
     *
     * @param paintGround the canvas to be drawn on
     *
     * @param button the button that was pressed to call the method, it is used to see if it was toggled
     *               on or off
     * @param EventHandlers these are the event handlers for when the user presses, drags, or releases the
     *                      mouse
     */

    //setting up the free draw function
    public static void freeDraw(Canvas paintGround, ToggleButton drawButton, EventHandler handlerRelease,
                                EventHandler handlerPress, EventHandler handlerDrag) {
        if (drawButton.isSelected()) {

            paintGround.addEventHandler(MouseEvent.MOUSE_PRESSED, handlerPress);
            paintGround.addEventHandler(MouseEvent.MOUSE_DRAGGED, handlerDrag);
            paintGround.addEventHandler(MouseEvent.MOUSE_RELEASED, handlerRelease);
            Saving.setChangeCheck(true);

        } else {
            paintGround.removeEventHandler(MouseEvent.MOUSE_PRESSED, handlerPress);
            paintGround.removeEventHandler(MouseEvent.MOUSE_DRAGGED, handlerDrag);
            paintGround.removeEventHandler(MouseEvent.MOUSE_RELEASED, handlerRelease);
        }
    }

    //setting up the line function
    public static void drawLine(Canvas paintGround, ToggleButton lineDrawButton, EventHandler linePress,
                                EventHandler lineDrag, EventHandler lineRelease) {
        if (lineDrawButton.isSelected()) {

            paintGround.addEventHandler(MouseEvent.MOUSE_PRESSED, linePress);
            paintGround.addEventHandler(MouseEvent.MOUSE_DRAGGED, lineDrag);
            paintGround.addEventHandler(MouseEvent.MOUSE_RELEASED, lineRelease);
            Saving.setChangeCheck(true);
        } else {

            paintGround.removeEventHandler(MouseEvent.MOUSE_PRESSED, linePress);
            paintGround.removeEventHandler(MouseEvent.MOUSE_DRAGGED, lineDrag);
            paintGround.removeEventHandler(MouseEvent.MOUSE_RELEASED, lineRelease);
        }
    }

    public static void eraseDraw(Canvas paintGround, ToggleButton eraseButton, EventHandler erasePress,
                                 EventHandler eraseDrag, EventHandler eraseRelease) {

        if (eraseButton.isSelected()) {

            paintGround.addEventHandler(MouseEvent.MOUSE_PRESSED, erasePress);
            paintGround.addEventHandler(MouseEvent.MOUSE_DRAGGED, eraseDrag);
            paintGround.addEventHandler(MouseEvent.MOUSE_RELEASED, eraseRelease);
            Saving.setChangeCheck(true);

        } else {
            paintGround.removeEventHandler(MouseEvent.MOUSE_PRESSED, erasePress);
            paintGround.removeEventHandler(MouseEvent.MOUSE_DRAGGED, eraseDrag);
            paintGround.removeEventHandler(MouseEvent.MOUSE_RELEASED, eraseRelease);
        }
    }

    //setting up the color dropper function
    public static void dropSetup(Canvas paintGround, ToggleButton colorDropper, EventHandler colorGet) {
        if (colorDropper.isSelected()) {

            paintGround.addEventHandler(MouseEvent.MOUSE_PRESSED, colorGet);
            Saving.setChangeCheck(true);
        } else {

            paintGround.removeEventHandler(MouseEvent.MOUSE_PRESSED, colorGet);
        }
    }

    //setting up the rectangle function
    public static void makeRect(Canvas paintGround, ToggleButton makeRectButton, EventHandler rectPress,
                                EventHandler rectDrag, EventHandler rectRelease) {
        if (makeRectButton.isSelected()) {

            paintGround.addEventHandler(MouseEvent.MOUSE_PRESSED, rectPress);
            paintGround.addEventHandler(MouseEvent.MOUSE_DRAGGED, rectDrag);
            paintGround.addEventHandler(MouseEvent.MOUSE_RELEASED, rectRelease);
            Saving.setChangeCheck(true);
        } else {

            paintGround.removeEventHandler(MouseEvent.MOUSE_PRESSED, rectPress);
            paintGround.addEventHandler(MouseEvent.MOUSE_DRAGGED, rectDrag);
            paintGround.removeEventHandler(MouseEvent.MOUSE_RELEASED, rectRelease);
        }


    }

    //setting up the square function
    public static void makeSqr(Canvas paintGround, ToggleButton makeSqrButton, EventHandler sqrPress,
                               EventHandler sqrDrag, EventHandler sqrRelease) {
        if (makeSqrButton.isSelected()) {

            paintGround.addEventHandler(MouseEvent.MOUSE_PRESSED, sqrPress);
            paintGround.addEventHandler(MouseEvent.MOUSE_DRAGGED, sqrDrag);
            paintGround.addEventHandler(MouseEvent.MOUSE_RELEASED, sqrRelease);
            Saving.setChangeCheck(true);
        } else {

            paintGround.removeEventHandler(MouseEvent.MOUSE_PRESSED, sqrPress);
            paintGround.addEventHandler(MouseEvent.MOUSE_DRAGGED, sqrDrag);
            paintGround.removeEventHandler(MouseEvent.MOUSE_RELEASED, sqrRelease);
        }


    }

    //setting up the ellipse function
    public static void makeElip(Canvas paintGround, ToggleButton makeElipButton, EventHandler elipPress,
                                EventHandler elipRelease) {
        if (makeElipButton.isSelected()) {

            paintGround.addEventHandler(MouseEvent.MOUSE_PRESSED, elipPress);
            paintGround.addEventHandler(MouseEvent.MOUSE_RELEASED, elipRelease);
            Saving.setChangeCheck(true);
        } else {

            paintGround.removeEventHandler(MouseEvent.MOUSE_PRESSED, elipPress);
            paintGround.removeEventHandler(MouseEvent.MOUSE_RELEASED, elipRelease);
        }


    }

    public static void makeTri(Canvas paintGround, Toggle makeTriButton, EventHandler triPress,
                               EventHandler triDrag, EventHandler triRelease) {
        if (makeTriButton.isSelected()) {

            paintGround.addEventHandler(MouseEvent.MOUSE_PRESSED, triPress);
            paintGround.addEventHandler(MouseEvent.MOUSE_DRAGGED, triDrag);
            paintGround.addEventHandler(MouseEvent.MOUSE_RELEASED, triRelease);
            Saving.setChangeCheck(true);
        } else {

            paintGround.removeEventHandler(MouseEvent.MOUSE_PRESSED, triPress);
            paintGround.addEventHandler(MouseEvent.MOUSE_DRAGGED, triDrag);
            paintGround.removeEventHandler(MouseEvent.MOUSE_RELEASED, triRelease);
        }

    }

    //setting up the circle function
    public static void makeCircle(Canvas paintGround, ToggleButton makeCircleButton, EventHandler circlePress,
                                  EventHandler circleDrag, EventHandler circleRelease) {
        if (makeCircleButton.isSelected()) {

            paintGround.addEventHandler(MouseEvent.MOUSE_PRESSED, circlePress);
            paintGround.addEventHandler(MouseEvent.MOUSE_DRAGGED, circleDrag);
            paintGround.addEventHandler(MouseEvent.MOUSE_RELEASED, circleRelease);
            Saving.setChangeCheck(true);
        } else {

            paintGround.removeEventHandler(MouseEvent.MOUSE_PRESSED, circlePress);
            paintGround.addEventHandler(MouseEvent.MOUSE_DRAGGED, circleDrag);
            paintGround.removeEventHandler(MouseEvent.MOUSE_RELEASED, circleRelease);
        }


    }


    //setting up the text function
    public static void makeText(Canvas paintGround, ToggleButton makeTextButton, EventHandler textPress) {
        if (makeTextButton.isSelected()) {

            paintGround.addEventHandler(MouseEvent.MOUSE_PRESSED, textPress);
            Saving.setChangeCheck(true);
        } else {

            paintGround.removeEventHandler(MouseEvent.MOUSE_PRESSED, textPress);

        }
    }

    public static int sideNumber = 3;

    public static void customShape(Canvas paintGround, EventHandler customPress, EventHandler customDrag,
                                   EventHandler customRelease, ToggleButton customShapeButton){
        if(customShapeButton.isSelected()){
            customShapeStart();
            paintGround.addEventHandler(MouseEvent.MOUSE_PRESSED,customPress);
            paintGround.addEventHandler(MouseEvent.MOUSE_DRAGGED,customDrag);
            paintGround.addEventHandler(MouseEvent.MOUSE_RELEASED,customRelease);
        }
        else{
            paintGround.removeEventHandler(MouseEvent.MOUSE_PRESSED, customPress);
            paintGround.addEventHandler(MouseEvent.MOUSE_DRAGGED,customDrag);
            paintGround.removeEventHandler(MouseEvent.MOUSE_RELEASED, customRelease);
        }

    }

    //setting up the customShape
    public static void customShapeStart() {
        TextField userSideNum = new TextField(String.valueOf(sideNumber));

        Button sideConfirm = new Button("Confirm Sides");

        GridPane root = new GridPane();
        root.setAlignment(Pos.CENTER);

        root.add(sideConfirm, 0, 0);
        root.add(userSideNum, 1, 0);

        userSideNum.setPrefWidth(70);
        sideConfirm.setPrefWidth(70);

        sideConfirm.setOnAction(e -> setSideAmount(Integer.parseInt(userSideNum.getText())));
        Scene scene = new Scene(root, 200, 200);

        Stage releaseWindow = new Stage();
        releaseWindow.setTitle("Custom Polygon");
        releaseWindow.setScene(scene);

        releaseWindow.setX(200);
        releaseWindow.setY(100);

        //showing
        releaseWindow.show();
        Saving.setChangeCheck(true);

    }

    public static void setSideAmount(Integer userSideNum) {
        sideNumber = userSideNum;

    }


    public static double[] setPolygonSidesX(double centerX, double radius, int sides, double[] xpoint) {

        final double angleStep = Math.PI * 2 / sides;
        double angle = 0;
        for (int i = 0; i < sides; i++, angle += angleStep) {
            xpoint[i] = Math.sin(angle) * radius + centerX;
        }
        return xpoint;
    }
    public static double[] setPolygonSidesY(double centerY, double radius, int sides, double[] ypoint) {

        final double angleStep = Math.PI * 2 / sides;
        double angle = 0;
        for (int i = 0; i < sides; i++, angle += angleStep) {
            ypoint[i] = Math.cos(angle) * radius + centerY;
        }
        return ypoint;
    }

    public static void tranMovement(Canvas paintGround, GraphicsContext graphCon, ToggleButton movePartsButton,
                                    EventHandler movePress, EventHandler moveRelease){
        if(movePartsButton.isSelected()){
            paintGround.addEventHandler(MouseEvent.MOUSE_PRESSED,movePress);
            paintGround.addEventHandler(MouseEvent.MOUSE_RELEASED,moveRelease);
        }
        else{
            paintGround.removeEventHandler(MouseEvent.MOUSE_PRESSED, movePress);
            paintGround.removeEventHandler(MouseEvent.MOUSE_RELEASED, moveRelease);
        }
    }

    public static void movePosition(double currentX, double currentY,Canvas paintGround, GraphicsContext
            graphCon, Image image){
        //making a new window for the transition function
        TextField newX = new TextField(String.valueOf(currentX));
        TextField newY = new TextField(String.valueOf(currentY));
        Button moveLoc = new Button("New Location");
        GridPane root = new GridPane();
        root.setAlignment(Pos.CENTER);

        //setting up the gridpane
        root.add(moveLoc, 0, 0);
        root.add(newX, 1, 0);
        root.add(newY,1,1);

        newX.setPrefWidth(70);
        newY.setPrefWidth(70);
        moveLoc.setPrefWidth(70);

        //setting up the button
        moveLoc.setOnAction(e -> newLocation(Double.parseDouble(newX.getText()),
                Double.parseDouble(newY.getText()), paintGround, graphCon, image));
        Scene scene = new Scene(root, 175, 175);

        Stage releaseWindow = new Stage();
        releaseWindow.setTitle("New Location for Selected Area");
        releaseWindow.setScene(scene);

        releaseWindow.setX(200);
        releaseWindow.setY(100);

        //showing
        releaseWindow.show();
        Saving.setChangeCheck(true);
    }

    public static void fillCanvas(Canvas paintGround, GraphicsContext graphCon, ToggleButton fillCanvasButton,
                                    EventHandler fillPress){
        if(fillCanvasButton.isSelected()){
            paintGround.addEventHandler(MouseEvent.MOUSE_PRESSED,fillPress);
        }
        else{
            paintGround.removeEventHandler(MouseEvent.MOUSE_PRESSED, fillPress);

        }
    }

    public static void copyArea(Canvas paintGround, GraphicsContext graphCon, ToggleButton copyButton,
                                  EventHandler copyPress, EventHandler copyRelease){
        if(copyButton.isSelected()){
            paintGround.addEventHandler(MouseEvent.MOUSE_PRESSED,copyPress);
            paintGround.addEventHandler(MouseEvent.MOUSE_RELEASED,copyRelease);
        }
        else{
            paintGround.removeEventHandler(MouseEvent.MOUSE_PRESSED, copyPress);
            paintGround.removeEventHandler(MouseEvent.MOUSE_RELEASED, copyRelease);

        }
    }

    public static void pasteArea(Canvas paintGround, GraphicsContext graphCon, ToggleButton pasteButton,
                                EventHandler pastePress){
        if(pasteButton.isSelected()){
            paintGround.addEventHandler(MouseEvent.MOUSE_PRESSED,pastePress);

        }
        else{
            paintGround.removeEventHandler(MouseEvent.MOUSE_PRESSED, pastePress);

        }
    }


    public static void newLocation(double newX, double newY, Canvas paintGround,
                                   GraphicsContext graphCon, Image image){
        //set the new location of the captured area
        currentX = newX;
        currentY = newY;
        //drawing the area at the new location
        graphCon.drawImage(image, currentX-0.5, currentY-0.5);


    }


    /**
     *Setting the icons for the toggle buttons
     */
    public static void setImages(ToggleButton freeDrawButton, ToggleButton lineDrawButton, ToggleButton eraseButton,
                                 ToggleButton makeSqrButton, ToggleButton makeRectButton, ToggleButton makeElipButton,
                                 ToggleButton makeCircleButton, ToggleButton makeTriButton, ToggleButton customShapeButton,
                                 ToggleButton colorDropper, ToggleButton movePartsButton, ToggleButton fillCanvasButton
    ){

        Image freeDrawImg = new Image("https://upload.wikimedia.org/wikipedia/commons/thumb/a/ac/Black_pencil.svg/1200px-Black_pencil.svg.png");
        ImageView freeDrawView = new ImageView(freeDrawImg);
        freeDrawView.setFitHeight(20);
        freeDrawView.setPreserveRatio(true);
        freeDrawButton.setGraphic(freeDrawView);
        freeDrawButton.setTooltip(new Tooltip("Free Draw"));

        Image lineDrawImg = new Image("https://www.clipartmax.com/png/small/325-3251124_straight-line-linear-flat-icon-line-tool-icon.png");
        ImageView lineDrawView = new ImageView(lineDrawImg);
        lineDrawView.setFitHeight(20);
        lineDrawView.setPreserveRatio(true);
        lineDrawButton.setGraphic(lineDrawView);
        lineDrawButton.setTooltip(new Tooltip("Line"));

        Image eraseImg = new Image("https://icons.iconarchive.com/icons/iconsmind/outline/512/Eraser-icon.png");
        ImageView eraseView = new ImageView(eraseImg);
        eraseView.setFitHeight(20);
        eraseView.setPreserveRatio(true);
        eraseButton.setGraphic(eraseView);
        eraseButton.setTooltip(new Tooltip("Erase"));

        Image sqrImg = new Image("https://d1nhio0ox7pgb.cloudfront.net/_img/o_collection_png/green_dark_grey/512x512/plain/shape_square.png");
        ImageView sqrView = new ImageView(sqrImg);
        sqrView.setFitHeight(20);
        sqrView.setPreserveRatio(true);
        makeSqrButton.setGraphic(sqrView);
        makeSqrButton.setTooltip(new Tooltip("Square"));


        Image rectImg = new Image("https://static.thenounproject.com/png/12999-200.png");
        ImageView rectView = new ImageView(rectImg);
        rectView.setFitHeight(20);
        rectView.setPreserveRatio(true);
        makeRectButton.setGraphic(rectView);
        makeRectButton.setTooltip(new Tooltip("Rectangle"));

        Image elipImg = new Image("https://cdn2.iconfinder.com/data/icons/math-numbers-1/24/zero-512.png");
        ImageView elipView = new ImageView(elipImg);
        elipView.setFitHeight(20);
        elipView.setPreserveRatio(true);
        makeElipButton.setGraphic(elipView);
        makeElipButton.setTooltip(new Tooltip("Elipse"));

        Image circleImg = new Image("https://cdn4.iconfinder.com/data/icons/ionicons/512/icon-ios7-circle-outline-512.png");
        ImageView circleView = new ImageView(circleImg);
        circleView.setFitHeight(20);
        circleView.setPreserveRatio(true);
        makeCircleButton.setGraphic(circleView);
        makeCircleButton.setTooltip(new Tooltip("Circle"));

        Image triImg = new Image("https://static.thenounproject.com/png/340352-200.png");
        ImageView triView = new ImageView(triImg);
        triView.setFitHeight(20);
        triView.setPreserveRatio(true);
        makeTriButton.setGraphic(triView);
        makeTriButton.setTooltip(new Tooltip("Triangle"));

        Image customShapeImg = new Image("https://static.thenounproject.com/png/2481973-200.png");
        ImageView customShapeView = new ImageView(customShapeImg);
        customShapeView.setFitHeight(20);
        customShapeView.setPreserveRatio(true);
        customShapeButton.setGraphic(customShapeView);
        customShapeButton.setTooltip(new Tooltip("Custom Sided Shape"));

        Image colorDropImg = new Image("https://static-00.iconduck.com/assets.00/magnifying-glass-icon-512x512-bavuz0m7.png");
        ImageView colorDropView = new ImageView(colorDropImg);
        colorDropView.setFitHeight(20);
        colorDropView.setPreserveRatio(true);
        colorDropper.setGraphic(colorDropView);
        colorDropper.setTooltip(new Tooltip("Color Dropper"));

        Image moveImg = new Image("https://cdn-icons-png.flaticon.com/512/14/14296.png");
        ImageView moveView = new ImageView(moveImg);
        moveView.setFitHeight(20);
        moveView.setPreserveRatio(true);
        movePartsButton.setGraphic(moveView);
        movePartsButton.setTooltip(new Tooltip("Move"));

        Image fillImg = new Image("https://www.pngkey.com/png/detail/117-1170821_paint-pouring-bucket-color-colour-drip-acrylic-comments.png");
        ImageView fillView = new ImageView(fillImg);
        fillView.setFitHeight(20);
        fillView.setPreserveRatio(true);
        fillCanvasButton.setGraphic(fillView);
        fillCanvasButton.setTooltip(new Tooltip("Fill Canvas"));


    }

}
