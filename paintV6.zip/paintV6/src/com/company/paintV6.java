package com.company;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Rectangle2D;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.SnapshotParameters;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.*;
import javafx.scene.image.Image;
import javafx.scene.input.*;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.scene.layout.VBox;
import javafx.scene.control.*;
import javafx.scene.control.ToolBar;
import javafx.scene.control.ColorPicker;
import javafx.stage.WindowEvent;
import javafx.util.Duration;
import java.util.Optional;
import java.util.Stack;



/**
 *The core of what makes the Paint Program work
 *      Makes a window that the user can interact
 *      and draw on to their hearts content
 *
 */
public class paintV6 extends Application {

    //the starting x and y coordinate for drawing on the canvas
    public static double currentX;
    public static double currentY;

    //a tab idea
    private int tabId = 1;


    //stacks of screenshots of previous/undone canvases
    private Stack<Image> pastCanvas = new Stack<>();
    private Stack<Image> futureCanvas = new Stack<>();

    //the default amount of seconds for an autosave
    public static int autoTime = 10;

    //images used for autosave
    Image autoImage;
    Image copiedArea;

    //setting up the tabs
    TabPane tabBar = new TabPane();

    Image actualTemplate;

    //setting up the scrollbars
    ScrollPane scroll = new ScrollPane();


    /**
     *Starts the Program up
     *
     * @param s the default Stage that is added to throughout the entire program
     */
    public void start(Stage s) {

        //setting up the canvas
        s.setTitle("Paint");

        //setting the visual box
        VBox vb = new VBox();

        //the default Canvas
        Canvas paintGround = new Canvas(600, 600);
        //graphic context for the canvas
        GraphicsContext graphCon = paintGround.getGraphicsContext2D();


        //Making a Toolbar
        ToolBar toolBarOne = new ToolBar();
        ToolBar toolBarTwo = new ToolBar();

        //setting up the defaults for the ColorPickers
        ColorPicker colorPick = new ColorPicker(Color.RED);
        ColorPicker outlinePick = new ColorPicker(Color.BLACK);
        graphCon.setFill(colorPick.getValue());

        graphCon.setStroke(colorPick.getValue());
        graphCon.setLineWidth(1);

        //making the buttons for the Toolbar
        ToggleButton freeDrawButton = new ToggleButton();
        ToggleButton lineDrawButton = new ToggleButton();
        ToggleButton eraseButton = new ToggleButton();
        ToggleButton colorDropper = new ToggleButton();
        ToggleButton makeSqrButton = new ToggleButton();
        ToggleButton makeRectButton = new ToggleButton();
        ToggleButton makeElipButton = new ToggleButton();
        ToggleButton makeTriButton = new ToggleButton();
        ToggleButton makeCircleButton = new ToggleButton();
        ToggleButton makeTextButton = new ToggleButton("Text");
        ToggleButton customShapeButton = new ToggleButton();
        ToggleButton movePartsButton = new ToggleButton();
        ToggleButton fillCanvasButton = new ToggleButton();
        ToggleButton copyButton = new ToggleButton("Copy");
        ToggleButton pasteButton = new ToggleButton("Paste");

        ToolBarFun.setImages(freeDrawButton, lineDrawButton, eraseButton, makeSqrButton, makeRectButton,
                makeElipButton, makeCircleButton, makeTriButton, customShapeButton, colorDropper, movePartsButton, fillCanvasButton);



        //putting the buttons on the Toolbar
        toolBarOne.getItems().addAll(freeDrawButton, lineDrawButton, eraseButton,
                makeSqrButton, makeRectButton, makeElipButton, makeTriButton, makeCircleButton,
                customShapeButton, makeTextButton, movePartsButton);
        toolBarTwo.getItems().addAll(colorPick, colorDropper, outlinePick, fillCanvasButton,
                copyButton,pasteButton);


        ////////////////////////////////////////////////////////////////////////////////////////////////////////
        /**
         *All of the event handlers that are used for the tools
         * Each of these are used for either a mouse click, drag, or release
         */

        //clicker for free draw
        EventHandler handlerPress = new EventHandler<MouseEvent>() {

            @Override
            public void handle(MouseEvent event) {
                UndoEdit.addUndoStack(pastCanvas, paintGround);
                graphCon.beginPath();
                graphCon.moveTo(event.getX(), event.getY());
                graphCon.setStroke(colorPick.getValue());
                graphCon.stroke();
            }
        };

        //release for free draw
        EventHandler handlerRelease = new EventHandler<MouseEvent>() {

            @Override
            public void handle(MouseEvent event) {


            }
        };
        //dragger for free draw
        EventHandler handlerDrag = new EventHandler<MouseEvent>() {

            @Override
            public void handle(MouseEvent event) {
                graphCon.lineTo(event.getX(), event.getY());
                graphCon.setStroke(colorPick.getValue());
                graphCon.stroke();
            }
        };

        EventHandler erasePress = new EventHandler<MouseEvent>() {

            @Override
            public void handle(MouseEvent event) {
                UndoEdit.addUndoStack(pastCanvas, paintGround);
                graphCon.beginPath();
                graphCon.moveTo(event.getX(), event.getY());
                graphCon.setStroke(Color.WHITE);
                graphCon.stroke();
            }
        };

        //release for free draw
        EventHandler eraseRelease = new EventHandler<MouseEvent>() {

            @Override
            public void handle(MouseEvent event) {

            }
        };
        //dragger for eraser draw
        EventHandler eraseDrag = new EventHandler<MouseEvent>() {

            @Override
            public void handle(MouseEvent event) {

                graphCon.lineTo(event.getX(), event.getY());
                graphCon.setStroke(Color.WHITE);
                graphCon.stroke();
            }
        };


        //clicker for line
        EventHandler linePress = new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                UndoEdit.addUndoStack(pastCanvas, paintGround);
                //graphCon.beginPath();
                //graphCon.moveTo(event.getX(), event.getY());
                WritableImage writableImage = new WritableImage((int) paintGround.getWidth(),
                        (int) paintGround.getHeight());
                actualTemplate = paintGround.snapshot(null, writableImage);

                currentX = event.getX();
                currentY = event.getY();
            }
        };

        EventHandler lineDrag = new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {

                graphCon.clearRect(0, 0, paintGround.getWidth(), paintGround.getHeight());
                graphCon.drawImage(actualTemplate, 0, 0);
                graphCon.setStroke(colorPick.getValue());
                graphCon.strokeLine(currentX, currentY, event.getX(), event.getY());
                //use a stack to peek and get what the canvas should look like
            }
        };


        //release for line
        EventHandler lineRelease = new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                //graphCon.setStroke(colorPick.getValue());
                //graphCon.strokeLine(currentX, currentY, event.getX(), event.getY());

            }
        };

        //setting up color dropper
        EventHandler colorGet = new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                currentX = event.getX();
                currentY = event.getY();
                int intX = (int) currentX;
                int intY = (int) currentY;

                WritableImage snapshotImage = new WritableImage((int) paintGround.getWidth(), (int) paintGround.getHeight());
                snapshotImage = paintGround.snapshot(null, snapshotImage);
                PixelReader r = snapshotImage.getPixelReader();
                Color pixelColor = r.getColor(intX, intY);

                colorPick.setValue(pixelColor);
            }
        };
        //quicksave shortcut
        EventHandler quickSave = new EventHandler<KeyEvent>() {
            KeyCombination keyComb = new KeyCodeCombination(KeyCode.S, KeyCombination.SHIFT_ANY);

            public void handle(KeyEvent ke) {
                if (keyComb.match(ke)) {
                    Saving.saveCanvas(paintGround, s);
                }
            }
        };

        //quickopen shortcut
        EventHandler quickOpen = new EventHandler<KeyEvent>() {
            KeyCombination keyComb = new KeyCodeCombination(KeyCode.O, KeyCombination.SHIFT_ANY);

            public void handle(KeyEvent op) {
                if (keyComb.match(op)) {
                    OpenPicture.openPicture(pastCanvas, paintGround, graphCon);
                }
            }
        };

        EventHandler quickUndo = new EventHandler<KeyEvent>() {
            KeyCombination keyComb = new KeyCodeCombination(KeyCode.Z, KeyCombination.SHIFT_ANY);

            public void handle(KeyEvent op) {
                if (keyComb.match(op)) {
                    UndoEdit.undo(pastCanvas, futureCanvas, paintGround, graphCon);
                }
            }
        };

        //clicker for rectangle
        EventHandler rectPress = new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                UndoEdit.addUndoStack(pastCanvas, paintGround);
                WritableImage writableImage = new WritableImage((int) paintGround.getWidth(),
                        (int) paintGround.getHeight());
                actualTemplate = paintGround.snapshot(null, writableImage);
                currentX = event.getX();
                currentY = event.getY();
            }
        };

        EventHandler rectDrag = new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                graphCon.setFill(colorPick.getValue());
                graphCon.clearRect(0, 0, paintGround.getWidth(), paintGround.getHeight());
                graphCon.drawImage(actualTemplate, 0, 0);

                double rectWidth = event.getX() - currentX;
                double rectHeight = event.getY() - currentY;
                if (rectWidth < 0) {
                    rectWidth = -rectWidth;
                    currentX = currentX - rectWidth;
                }

                if (rectHeight < 0) {
                    rectHeight = -rectHeight;
                    currentY = currentY - rectHeight;
                }
                graphCon.fillRect(currentX, currentY, rectWidth, rectHeight);
                graphCon.setStroke(outlinePick.getValue());
                graphCon.strokeRect(currentX, currentY, rectWidth, rectHeight);
            }
        };

        //release for rectangle
        EventHandler rectRelease = new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                graphCon.setFill(colorPick.getValue());
                double rectWidth = event.getX() - currentX;
                double rectHeight = event.getY() - currentY;
                if (rectWidth < 0) {
                    rectWidth = -rectWidth;
                    currentX = currentX - rectWidth;
                }

                if (rectHeight < 0) {
                    rectHeight = -rectHeight;
                    currentY = currentY - rectHeight;
                }
                graphCon.fillRect(currentX, currentY, rectWidth, rectHeight);
                graphCon.setStroke(outlinePick.getValue());
                graphCon.strokeRect(currentX, currentY, rectWidth, rectHeight);
            }
        };

        //click for square
        EventHandler sqrPress = new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                UndoEdit.addUndoStack(pastCanvas, paintGround);
                WritableImage writableImage = new WritableImage((int) paintGround.getWidth(),
                        (int) paintGround.getHeight());
                actualTemplate = paintGround.snapshot(null, writableImage);
                currentX = event.getX();
                currentY = event.getY();
            }
        };

        EventHandler sqrDrag = new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                graphCon.setFill(colorPick.getValue());

                graphCon.clearRect(0, 0, paintGround.getWidth(), paintGround.getHeight());
                graphCon.drawImage(actualTemplate, 0, 0);

                double rectWidth = event.getX() - currentX;
                double rectHeight = event.getY() - currentY;

                if (rectWidth < 0) {
                    rectWidth = -rectWidth;
                    currentX = currentX - rectWidth;
                }

                if (rectHeight < 0) {
                    rectHeight = -rectHeight;
                    currentY = currentY - rectHeight;
                }
                if (Math.abs(rectWidth) < Math.abs(rectHeight)) {
                    rectHeight = rectWidth;
                } else if (Math.abs(rectWidth) > Math.abs(rectHeight)) {
                    rectWidth = rectHeight;
                }

                graphCon.fillRect(currentX, currentY, rectWidth, rectHeight);
                graphCon.setStroke(outlinePick.getValue());
                graphCon.strokeRect(currentX, currentY, rectWidth, rectHeight);
            }
        };


        //release for square
        EventHandler sqrRelease = new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                graphCon.setFill(colorPick.getValue());


                double rectWidth = event.getX() - currentX;
                double rectHeight = event.getY() - currentY;

                if (rectWidth < 0) {
                    rectWidth = -rectWidth;
                    currentX = currentX - rectWidth;
                }

                if (rectHeight < 0) {
                    rectHeight = -rectHeight;
                    currentY = currentY - rectHeight;
                }
                if (Math.abs(rectWidth) < Math.abs(rectHeight)) {
                    rectHeight = rectWidth;
                } else if (Math.abs(rectWidth) > Math.abs(rectHeight)) {
                    rectWidth = rectHeight;
                }

                graphCon.fillRect(currentX, currentY, rectWidth, rectHeight);
                graphCon.setStroke(outlinePick.getValue());
                graphCon.strokeRect(currentX, currentY, rectWidth, rectHeight);
            }
        };

        //click for elipse
        EventHandler elipPress = new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                UndoEdit.addUndoStack(pastCanvas, paintGround);
                currentX = event.getX();
                currentY = event.getY();
            }
        };

        //release for elipse
        EventHandler elipRelease = new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {

                double elipWidth = event.getX() - currentX;
                double elipHeight = event.getY() - currentY;
                graphCon.setFill(colorPick.getValue());
                if (elipWidth < 0) {
                    elipWidth = -elipWidth;
                    currentX = currentX - elipWidth;
                }

                if (elipHeight < 0) {
                    elipHeight = -elipHeight;
                    currentY = currentY - elipHeight;
                }

                graphCon.fillOval(currentX, currentY, elipWidth, elipHeight);
                graphCon.setStroke(outlinePick.getValue());
                graphCon.strokeOval(currentX, currentY, elipWidth, elipHeight);
            }
        };

        //click for circle
        EventHandler triPress = new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                UndoEdit.addUndoStack(pastCanvas, paintGround);
                WritableImage writableImage = new WritableImage((int) paintGround.getWidth(),
                        (int) paintGround.getHeight());
                actualTemplate = paintGround.snapshot(null, writableImage);
                currentX = event.getX();
                currentY = event.getY();
            }
        };

        EventHandler triDrag = new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {

                graphCon.clearRect(0, 0, paintGround.getWidth(), paintGround.getHeight());
                graphCon.drawImage(actualTemplate, 0, 0);
                double triWidth = event.getX();
                double triHeight = event.getY();
                double[] xpoints = new double[3];
                double[] ypoints = new double[3];
                xpoints[0] = currentX;
                ypoints[0] = triHeight;
                xpoints[1] = triWidth;
                ypoints[1] = triHeight;
                xpoints[2] = (currentX + triWidth) / 2;
                ypoints[2] = currentY;
                graphCon.setFill(colorPick.getValue());
                graphCon.fillPolygon(xpoints, ypoints, 3);
                graphCon.setStroke(outlinePick.getValue());
                graphCon.strokePolygon(xpoints, ypoints, 3);
            }
        };


        EventHandler triRelease = new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {

                double triWidth = event.getX();
                double triHeight = event.getY();
                double[] xpoints = new double[3];
                double[] ypoints = new double[3];
                xpoints[0] = currentX;
                ypoints[0] = triHeight;
                xpoints[1] = triWidth;
                ypoints[1] = triHeight;
                xpoints[2] = (currentX + triWidth) / 2;
                ypoints[2] = currentY;
                graphCon.setFill(colorPick.getValue());
                graphCon.fillPolygon(xpoints, ypoints, 3);
                graphCon.setStroke(outlinePick.getValue());
                graphCon.strokePolygon(xpoints, ypoints, 3);
            }
        };

        //click for circle
        EventHandler circlePress = new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                UndoEdit.addUndoStack(pastCanvas, paintGround);
                WritableImage writableImage = new WritableImage((int) paintGround.getWidth(),
                        (int) paintGround.getHeight());
                actualTemplate = paintGround.snapshot(null, writableImage);
                currentX = event.getX();
                currentY = event.getY();
            }
        };

        EventHandler circleDrag = new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {

                graphCon.clearRect(0, 0, paintGround.getWidth(), paintGround.getHeight());
                graphCon.drawImage(actualTemplate, 0, 0);

                double elipWidth = event.getX() - currentX;
                double elipHeight = event.getY() - currentY;
                graphCon.setFill(colorPick.getValue());
                if (elipWidth < 0) {
                    elipWidth = -elipWidth;
                    currentX = currentX - elipWidth;
                }

                if (elipHeight < 0) {
                    elipHeight = -elipHeight;
                    currentY = currentY - elipHeight;
                }
                if (Math.abs(elipWidth) < Math.abs(elipHeight)) {
                    elipHeight = elipWidth;
                } else if (Math.abs(elipWidth) > Math.abs(elipHeight)) {
                    elipWidth = elipHeight;
                }

                graphCon.fillOval(currentX, currentY, elipWidth, elipHeight);
                graphCon.setStroke(outlinePick.getValue());
                graphCon.strokeOval(currentX, currentY, elipWidth, elipHeight);
            }
        };


        //release for circle
        EventHandler circleRelease = new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {

                double elipWidth = event.getX() - currentX;
                double elipHeight = event.getY() - currentY;
                graphCon.setFill(colorPick.getValue());
                if (elipWidth < 0) {
                    elipWidth = -elipWidth;
                    currentX = currentX - elipWidth;
                }

                if (elipHeight < 0) {
                    elipHeight = -elipHeight;
                    currentY = currentY - elipHeight;
                }
                if (Math.abs(elipWidth) < Math.abs(elipHeight)) {
                    elipHeight = elipWidth;
                } else if (Math.abs(elipWidth) > Math.abs(elipHeight)) {
                    elipWidth = elipHeight;
                }

                graphCon.fillOval(currentX, currentY, elipWidth, elipHeight);
                graphCon.setStroke(outlinePick.getValue());
                graphCon.strokeOval(currentX, currentY, elipWidth, elipHeight);
            }
        };

        //click for text
        EventHandler textPress = new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                UndoEdit.addUndoStack(pastCanvas, paintGround);
                TextInputDialog dialog = new TextInputDialog("Input Text");

                dialog.setTitle("");
                dialog.setHeaderText(null);

                Optional<String> result = dialog.showAndWait();

                result.ifPresent(name -> {
                    graphCon.setFill(colorPick.getValue());
                    graphCon.fillText(name, event.getX(), event.getY());

                });


            }
        };

        //setting up the custom shape
        EventHandler customPress = new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                UndoEdit.addUndoStack(pastCanvas, paintGround);
                WritableImage writableImage = new WritableImage((int) paintGround.getWidth(),
                        (int) paintGround.getHeight());
                actualTemplate = paintGround.snapshot(null, writableImage);
                currentX = event.getX();
                currentY = event.getY();
            }
        };

        EventHandler customDrag = new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {

                graphCon.clearRect(0, 0, paintGround.getWidth(), paintGround.getHeight());
                graphCon.drawImage(actualTemplate, 0, 0);

                double endWidth = event.getX();
                double endHeight = event.getY();

                double endWidthLength = Math.abs(endWidth - currentX);
                double endHeightLength = Math.abs(endHeight - currentY);

                if (endWidthLength < endHeightLength) {
                    endHeightLength = endWidthLength;
                } else if (endWidthLength > endHeightLength) {
                    endWidthLength = endHeightLength;
                }

                double centerX = (currentX + endWidth) / 2;
                double centerY = (currentY + endHeight) / 2;


                double radius = (endHeightLength / 2);


                double[] xpoints = new double[ToolBarFun.sideNumber];
                double[] ypoints = new double[ToolBarFun.sideNumber];

                xpoints = ToolBarFun.setPolygonSidesX(centerX, radius, ToolBarFun.sideNumber, xpoints);
                ypoints = ToolBarFun.setPolygonSidesY(centerY, radius, ToolBarFun.sideNumber, ypoints);

                graphCon.setFill(colorPick.getValue());


                graphCon.fillPolygon(xpoints, ypoints, ToolBarFun.sideNumber);
                graphCon.setStroke(outlinePick.getValue());
                graphCon.strokePolygon(xpoints, ypoints, ToolBarFun.sideNumber);
            }
        };


        //making the custom shape
        EventHandler customRelease = new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {

                double endWidth = event.getX();
                double endHeight = event.getY();

                double endWidthLength = Math.abs(endWidth - currentX);
                double endHeightLength = Math.abs(endHeight - currentY);

                if (endWidthLength < endHeightLength) {
                    endHeightLength = endWidthLength;
                } else if (endWidthLength > endHeightLength) {
                    endWidthLength = endHeightLength;
                }

                double centerX = (currentX + endWidth) / 2;
                double centerY = (currentY + endHeight) / 2;


                double radius = (endHeightLength / 2);


                double[] xpoints = new double[ToolBarFun.sideNumber];
                double[] ypoints = new double[ToolBarFun.sideNumber];

                xpoints = ToolBarFun.setPolygonSidesX(centerX, radius, ToolBarFun.sideNumber, xpoints);
                ypoints = ToolBarFun.setPolygonSidesY(centerY, radius, ToolBarFun.sideNumber, ypoints);

                graphCon.setFill(colorPick.getValue());


                graphCon.fillPolygon(xpoints, ypoints, ToolBarFun.sideNumber);
                graphCon.setStroke(outlinePick.getValue());
                graphCon.strokePolygon(xpoints, ypoints, ToolBarFun.sideNumber);
            }
        };

        //setting up the move action
        EventHandler movePress = new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                UndoEdit.addUndoStack(pastCanvas, paintGround);
                currentX = event.getX();
                currentY = event.getY();
            }
        };

        //ending the move action
        EventHandler moveRelease = new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {

                double endWidth = event.getX();
                double endHeight = event.getY();


                double rectWidth = event.getX() - currentX;
                double rectHeight = event.getY() - currentY;
                if (rectWidth < 0) {
                    rectWidth = -rectWidth;
                    currentX = currentX - rectWidth;
                }

                if (rectHeight < 0) {
                    rectHeight = -rectHeight;
                    currentY = currentY - rectHeight;
                }

                Rectangle2D bound = new Rectangle2D((int) currentX, (int) currentY, (int) rectWidth, (int) rectHeight);

                SnapshotParameters params = new SnapshotParameters();
                params.setViewport(bound);
                WritableImage write = new WritableImage((int) rectWidth + 1, (int) rectHeight + 1);
                Image image = paintGround.snapshot(params, write);

                graphCon.clearRect(currentX, currentY, rectWidth, rectHeight);

                ToolBarFun.movePosition(currentX, currentY, paintGround, graphCon, image);
                //graphCon.drawImage(image, currentX-0.5, currentY-0.5);


                //graphCon.setFill(colorPick.getValue());


            }
        };

        EventHandler fillPress = new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                UndoEdit.addUndoStack(pastCanvas, paintGround);
                currentX = event.getX();
                currentY = event.getY();
                graphCon.setFill(colorPick.getValue());
                graphCon.fillRect(0,0,paintGround.getWidth(),paintGround.getHeight());
            }
        };


        //press to set the start of copying a section
        EventHandler copyPress = new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                UndoEdit.addUndoStack(pastCanvas, paintGround);
                currentX = event.getX();
                currentY = event.getY();
            }
        };



        //release for copying a section of the canvas
        EventHandler copyRelease = new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                //double endWidth = event.getX();
                //double endHeight = event.getY();

                double rectWidth = event.getX() - currentX;
                double rectHeight = event.getY() - currentY;
                if (rectWidth < 0) {
                    rectWidth = -rectWidth;
                    currentX = currentX - rectWidth;
                }

                if (rectHeight < 0) {
                    rectHeight = -rectHeight;
                    currentY = currentY - rectHeight;
                }

                Rectangle2D bound = new Rectangle2D((int) currentX, (int) currentY, (int) rectWidth, (int) rectHeight);

                SnapshotParameters params = new SnapshotParameters();
                params.setViewport(bound);
                WritableImage write = new WritableImage((int) rectWidth + 1, (int) rectHeight + 1);
                copiedArea = paintGround.snapshot(params, write);
            }
        };

        //pasting what was copied
        EventHandler pastePress = new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                UndoEdit.addUndoStack(pastCanvas, paintGround);
                currentX = event.getX();
                currentY = event.getY();

                graphCon.drawImage(copiedArea,currentX,currentY);
            }
        };


        ////////////////////////////////////////////////////////////////////////////////////////////////////////

        //setting up the button's actions
        freeDrawButton.setOnAction(fd -> ToolBarFun.freeDraw(paintGround, freeDrawButton, handlerRelease, handlerPress, handlerDrag));
        lineDrawButton.setOnAction(fl -> ToolBarFun.drawLine(paintGround, lineDrawButton, linePress, lineDrag, lineRelease));
        eraseButton.setOnAction(era -> ToolBarFun.eraseDraw(paintGround, eraseButton, erasePress, eraseDrag, eraseRelease));
        colorDropper.setOnAction(cd -> ToolBarFun.dropSetup(paintGround, colorDropper, colorGet));
        makeRectButton.setOnAction(mr -> ToolBarFun.makeRect(paintGround, makeRectButton, rectPress, rectDrag, rectRelease));
        makeSqrButton.setOnAction(ms -> ToolBarFun.makeSqr(paintGround, makeSqrButton, sqrPress, sqrDrag, sqrRelease));
        makeElipButton.setOnAction(me -> ToolBarFun.makeElip(paintGround, makeElipButton, elipPress, elipRelease));
        makeTriButton.setOnAction(mt -> ToolBarFun.makeTri(paintGround, makeTriButton, triPress, triDrag, triRelease));
        makeCircleButton.setOnAction(mc -> ToolBarFun.makeCircle(paintGround, makeCircleButton, circlePress, circleDrag, circleRelease));
        customShapeButton.setOnAction(cuSp -> ToolBarFun.customShape(paintGround, customPress, customDrag, customRelease, customShapeButton));
        makeTextButton.setOnAction(mt -> ToolBarFun.makeText(paintGround, makeTextButton, textPress));
        movePartsButton.setOnAction(moPa -> ToolBarFun.tranMovement(paintGround, graphCon, movePartsButton, movePress, moveRelease));
        fillCanvasButton.setOnAction(fica -> ToolBarFun.fillCanvas(paintGround,graphCon, fillCanvasButton,fillPress));
        copyButton.setOnAction(coar -> ToolBarFun.copyArea(paintGround,graphCon,copyButton,copyPress,copyRelease));
        pasteButton.setOnAction(paar -> ToolBarFun.pasteArea(paintGround,graphCon,pasteButton,pastePress));


        //putting the canvas in the ScrollPane
        scroll.setContent(new Group(paintGround));
        //scroll.setContent(canvasStack);

        //setting up the menu
        Menu mainFile = new Menu("File");
        Menu menuEdit = new Menu("Edit");
        Menu menuHelp = new Menu("Help");
        Menu menuTools = new Menu("Tools");

        //Setting up the menu items
        MenuItem m1 = new MenuItem("Open Image");
        MenuItem m2 = new MenuItem("Save As");
        MenuItem m3 = new MenuItem("Add Tab");
        MenuItem m4 = new MenuItem("Clear Canvas");
        MenuItem e1 = new MenuItem("Undo");
        MenuItem e2 = new MenuItem("Redo");
        MenuItem e3 = new MenuItem("Load Autosave");
        MenuItem e4 = new MenuItem("AutoSave Time");
        MenuItem e5 = new MenuItem("Zoom In");
        MenuItem e6 = new MenuItem("Zoom Out");
        MenuItem e7 = new MenuItem("Resize");
        MenuItem p1 = new MenuItem("Release Notes");
        MenuItem p2 = new MenuItem("Help");
        MenuItem p3 = new MenuItem("Group Members");



        //adding the items to the menus
        mainFile.getItems().addAll(m1, m2, m3, m4);
        menuEdit.getItems().addAll(e1, e2, e3, e4, e5, e6, e7);
        menuHelp.getItems().addAll(p1, p2, p3);
        //menuTools.getItems().addAll(t1,t2,t3);


        //setting up menu button presses
        m1.setOnAction(e -> OpenPicture.openPicture(pastCanvas, paintGround, graphCon));
        m2.setOnAction(sa -> Saving.saveCanvas(paintGround, s));
        m3.setOnAction(at -> addTab(tabBar));
        m4.setOnAction(clca -> clearCanvas(paintGround,graphCon,colorPick));

        e1.setOnAction(un -> UndoEdit.undo(pastCanvas, futureCanvas, paintGround, graphCon));
        e2.setOnAction(re -> UndoEdit.redo(pastCanvas, futureCanvas, paintGround, graphCon));
        e3.setOnAction(unau -> Saving.drawAutoSave(paintGround,graphCon,autoImage));
        e4.setOnAction(auti -> Saving.changeAutoTime(autoTime));
        e5.setOnAction(zi -> UseZoom.zoomIn(paintGround));
        e6.setOnAction(zo -> UseZoom.zoomOut(paintGround));
        e7.setOnAction(rs -> CanvasResize.resizeCanvas(paintGround, graphCon));

        p1.setOnAction(v -> RelNote.getRelNote());
        p2.setOnAction(hlp -> HelpInfo.getHelpInfo());




        //finalize menubar
        MenuBar mb = new MenuBar();

        mb.getMenus().addAll(mainFile, menuEdit, menuHelp);


        //letting the user set the width of the brush
        Slider widthSlide = new Slider(1, 50, 1);
        widthSlide.valueProperty().addListener(
                new ChangeListener<Number>() {

                    public void changed(ObservableValue<? extends Number>
                                                observable, Number oldValue, Number newValue) {

                        graphCon.setLineWidth((double) newValue);
                    }
                });

        Tab defaultTab = new Tab("Tab 0");
        defaultTab.setContent(scroll);
        tabBar.getTabs().add(defaultTab);



        //finalizing up visual box


        vb.getChildren().addAll(mb, toolBarOne, toolBarTwo, widthSlide, tabBar, scroll);


        //finalize scene
        Scene sRef = new Scene(vb, 600, 500);

        sRef.addEventFilter(KeyEvent.KEY_PRESSED, quickSave);
        sRef.addEventFilter(KeyEvent.KEY_PRESSED, quickOpen);
        sRef.addEventFilter(KeyEvent.KEY_PRESSED, quickUndo);

        graphCon.setFill(Color.WHITE);
        graphCon.fillRect(0, 0, paintGround.getWidth() * 10, paintGround.getHeight() * 10);
        graphCon.setFill(colorPick.getValue());

        WritableImage writableImage = new WritableImage((int) paintGround.getWidth(),
                (int) paintGround.getHeight());
        pastCanvas.push(paintGround.snapshot(null, writableImage));

        //showing the scene
        s.setScene(sRef);
        s.show();

        //safe save
        s.setOnCloseRequest(new EventHandler<WindowEvent>() {
            @Override
            public void handle(WindowEvent e) {
                if (Saving.getSaveCount() == 0) {
                    Saving.saveCanvas(paintGround, s);
                } else if (Saving.getChangeCheck() == true) {
                    Saving.saveCanvas(paintGround, s);
                }

                Platform.exit();
                System.exit(0);
            }
        });

        /*ScheduledExecutorService executorService = Executors.newSingleThreadScheduledExecutor();
        executorService.scheduleWithFixedDelay(() -> Saving.autoSave(paintGround,graphCon), 20, 10, TimeUnit.SECONDS);*/

        Timeline autoSaveLine = new Timeline(
                new KeyFrame(Duration.seconds(autoTime),
                        new EventHandler<ActionEvent>() {

                            @Override
                            public void handle(ActionEvent event) {
                                System.out.print("autosave...");
                                WritableImage writableImage = new WritableImage((int) paintGround.getWidth(),
                                        (int) paintGround.getHeight());
                                autoImage = paintGround.snapshot(null, writableImage);
                                System.out.println("  complete!");
                            }
                        }));
        autoSaveLine.setCycleCount(Timeline.INDEFINITE);
        autoSaveLine.play();
    }



    private void addTab(TabPane tabPane) {
        Tab tab = new Tab("Tab: " + tabId++);
        tab.setContent(createTabContent());
        tabPane.getTabs().add(tab);
        tabPane.getSelectionModel().select(tab);
    }

    /**
     *Getting the canvas added to the new Tab (DOESN'T WORK)
     * adds a default blank canvas that is the same size as the original canvas
     * and puts it into a scrollbar. Returns the scrollbar with the canvas inside.
     */
    private Node createTabContent() {
        Canvas canvas = new Canvas(600, 600);

        GraphicsContext gc = canvas.getGraphicsContext2D();
        gc.setFill(Color.WHITE);
        gc.fillRect(0, 0, canvas.getWidth(), canvas.getHeight());
        ScrollPane scroll = new ScrollPane();
        scroll.setContent(new Group(canvas));

        return scroll;
    }

    /**
     *Clears the entire Canvas of all colors. Making it a pure white canvas
     * @param paintGround       The Canvas that is going to be cleared
     *
     * @param graphCon          The GraphicContext that is being used to clear the Canvas
     *
     * @param colorPick         The ColorPicker that we use to reset the color value. As the
     *                          GraphicContext is being changed to white, it needs to be reset
     *                          to the original value
     */

    private void clearCanvas(Canvas paintGround, GraphicsContext graphCon, ColorPicker colorPick){
        UndoEdit.addUndoStack(pastCanvas, paintGround);
        graphCon.setFill(Color.WHITE);
        graphCon.fillRect(0,0, paintGround.getWidth(),paintGround.getHeight());
        graphCon.setFill(colorPick.getValue());
    }




    public static void main(String[] args) {
        launch();
    }
}