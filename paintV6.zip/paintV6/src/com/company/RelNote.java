package com.company;


import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import javafx.scene.control.*;
import java.io.IOException;

/**
 *The Class in charge of the release notes
 */
public class RelNote {

    public static void getRelNote() {

        //setting up the text for release notes
        Label secondLabel = new Label("Paint V 5.6/6" +
                "\nNew Features: bugfixes and cleanup " +
                "\n"+"\nPlanned Features: Missing Tabs, Logging, and Permanent Autosave");

        //making it show
        StackPane secondaryLayout = new StackPane();
        secondaryLayout.getChildren().add(secondLabel);

        Scene secondScene = new Scene(secondaryLayout, 500, 150);

        Stage releaseWindow = new Stage();
        releaseWindow.setTitle("Second Stage");
        releaseWindow.setScene(secondScene);

        releaseWindow.setX(200);
        releaseWindow.setY(100);

        //showing
        releaseWindow.show();
    }
};
